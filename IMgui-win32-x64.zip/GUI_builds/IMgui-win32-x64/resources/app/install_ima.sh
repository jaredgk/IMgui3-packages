cd IMa/
if hash mpicxx 2>/dev/null; then
	make xml
else
	make xml_singlecpu
fi
